<?php
/**
 * Plugin Name: いちばんやさしい WordPress テーマ Snow Monkey 講座 - 基礎編 - 専用プラグイン
 * Description: Udemy講座「いちばんやさしい WordPress テーマ Snow Monkey 講座 - 基礎編 -」を進める際に利用するプラグインです
 * Version: 1.0
 * Author: Koji Kuno
 */

/**
 * セキュリティ：WordPress 以外で実行された場合は終了
 */
defined( 'ABSPATH' ) || exit;

/**
 * カスタム投稿タイプ登録
 */
add_action( 'init', 'smbp_register_property_post_type' );

/**
 * カスタムタクソノミー登録
 */
add_action( 'init', 'smbp_register_property_taxonomies' );

/**
 * カスタム投稿タイプ「物件情報（property）」の登録
 */
function smbp_register_property_post_type() {
    $labels = [
        'name'               => '物件情報',
        'singular_name'      => '物件情報',
        'menu_name'          => '物件情報',
        'name_admin_bar'     => '物件',
        'add_new'            => '新規追加',
        'add_new_item'       => '物件を追加',
        'new_item'           => '新しい物件',
        'edit_item'          => '物件を編集',
        'view_item'          => '物件を表示',
        'all_items'          => 'すべての物件',
        'search_items'       => '物件を検索',
        'not_found'          => '物件が見つかりませんでした',
        'not_found_in_trash' => 'ゴミ箱に物件はありません',
    ];

    $args = [
        'labels'             => $labels,
        'public'             => true,
        'has_archive'        => true,
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-building',
        'supports'           => [ 'title', 'editor', 'thumbnail' ],
        'show_in_rest'       => true,
        'rewrite'            => [ 'slug' => 'property' ],
    ];

    register_post_type( 'property', $args );
}

/**
 * カスタムタクソノミーの登録
 */
function smbp_register_property_taxonomies() {
    $taxonomies = [
        'property-area' => [
            'singular'     => 'エリア',
            'plural'       => 'エリア',
            'hierarchical' => true,
        ],
        'property-type' => [
            'singular'     => '種別',
            'plural'       => '種別',
            'hierarchical' => true,
        ],
        'property-feature' => [
            'singular'     => '特徴',
            'plural'       => '特徴',
            'hierarchical' => false,
        ],
        'property-price-range' => [
            'singular'     => '価格帯',
            'plural'       => '価格帯',
            'hierarchical' => false,
        ],
        'property-floor-plan' => [
            'singular'     => '間取り',
            'plural'       => '間取り',
            'hierarchical' => false,
        ],
        'property-age' => [
            'singular'     => '築年数',
            'plural'       => '築年数',
            'hierarchical' => false,
        ],
        'property-status' => [
            'singular'     => 'ステータス',
            'plural'       => 'ステータス',
            'hierarchical' => false,
        ],
    ];

    foreach ( $taxonomies as $slug => $args ) {
        $labels = [
            'name'              => $args['plural'],
            'singular_name'     => $args['singular'],
            'search_items'      => $args['plural'] . 'を検索',
            'all_items'         => 'すべての' . $args['plural'],
            'parent_item'       => '親' . $args['singular'],
            'parent_item_colon' => '親' . $args['singular'] . ':',
            'edit_item'         => $args['singular'] . 'を編集',
            'update_item'       => $args['singular'] . 'を更新',
            'add_new_item'      => '新規' . $args['singular'],
            'new_item_name'     => '新しい' . $args['singular'],
            'menu_name'         => $args['plural'],
        ];

        register_taxonomy(
            $slug,
            [ 'property' ],
            [
                'labels'            => $labels,
                'hierarchical'      => $args['hierarchical'],
                'public'            => true,
                'show_ui'           => true,
                'show_admin_column' => true,
                'show_in_nav_menus' => true,
                'show_tagcloud'     => true,
                'show_in_rest'      => true,
                'rewrite'           => [ 'slug' => $slug ],
            ]
        );
    }
}

/**
 * カスタムメタフィールドを登録し、投稿編集画面に入力欄を追加・保存する
 */

// カスタムメタフィールドの登録（REST API・Gutenberg 対応）
function register_custom_meta_fields() {
	$fields = [ 'custom-field-test-01', 'custom-field-test-02', 'custom-field-test-03' ];

	foreach ( $fields as $field ) {
		register_post_meta(
			'post',
			$field,
			[
				'type'         => 'string',
				'single'       => true,
				'show_in_rest' => true, // REST API・ブロックエディタ対応
				'auth_callback'=> static function () {
					return current_user_can( 'edit_posts' );
				},
			]
		);
	}
}
add_action( 'init', 'register_custom_meta_fields' );